import java.util.Scanner;

public class Atlas {

    // Método para calcular el costo del hospedaje
    public static double calcularCostoHospedaje(int noches) {
        double costoPorNoche = 150000;
        double costoTotal = noches * costoPorNoche;
        if (noches >= 3) {
            double descuento = costoTotal * 0.10;
            costoTotal -= descuento;
        }
        return costoTotal;
    }

    // Método para calcular el costo del transporte
    public static double calcularCostoTransporte(String transporteIda, String transporteVuelta) {
        double costoBus = 80000;
        double costoAvion = 250000;
        double costoTotal = 0;

        if (transporteIda.equalsIgnoreCase("bus")) {
            costoTotal += costoBus;
        } else if (transporteIda.equalsIgnoreCase("avion")) {
            costoTotal += costoAvion;
        }

        if (transporteVuelta.equalsIgnoreCase("bus")) {
            costoTotal += costoBus;
        } else if (transporteVuelta.equalsIgnoreCase("avion")) {
            costoTotal += costoAvion;
        }

        return costoTotal;
    }

    // Método para calcular el costo total del paquete
    public static double calcularCostoTotal(double costoHospedaje, double costoTransporte) {
        double costoServicio = (costoHospedaje + costoTransporte) * 0.20;
        double costoTotal = costoHospedaje + costoTransporte + costoServicio;
        return costoTotal;
    }

    // Método para formatear un número con separadores de miles
    public static String formatearNumero(double numero) {
        // Convertir el número a una cadena con dos decimales
        String numeroStr = String.format("%.2f", numero);
        // Separar la parte entera de la parte decimal
        String[] partes = numeroStr.split("\\.");
        String parteEntera = partes[0];
        String parteDecimal = partes[1];
        // Agregar separadores de miles
        StringBuilder sb = new StringBuilder();
        int contador = 0;
        for (int i = parteEntera.length() - 1; i >= 0; i--) {
            sb.append(parteEntera.charAt(i));
            contador++;
            if (contador % 3 == 0 && i != 0) {
                sb.append(",");
            }
        }
        // Invertir la cadena para obtener el formato correcto
        String parteEnteraFormateada = sb.reverse().toString();
        // Combinar parte entera y decimal
        return parteEnteraFormateada + "." + parteDecimal;
    }

    // Método principal (main)
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Bienvenido a ATLAS - Paquetes de viaje para conciertos");

        // Solicitar información al usuario
        System.out.print("Ingrese el número de noches de hospedaje (mínimo 1, máximo 4): ");
        int noches = scanner.nextInt();
        while (noches < 1 || noches > 4) {
            System.out.println("El número de noches debe ser entre 1 y 4.");
            System.out.print("Ingrese el número de noches de hospedaje (mínimo 1, máximo 4): ");
            noches = scanner.nextInt();
        }

        scanner.nextLine(); // Limpiar el buffer del scanner

        System.out.print("Ingrese el medio de transporte para la ida (bus/avion): ");
        String transporteIda = scanner.nextLine().toLowerCase();
        while (!transporteIda.equals("bus") && !transporteIda.equals("avion")) {
            System.out.println("Opción no válida. Por favor, ingrese 'bus' o 'avion'.");
            System.out.print("Ingrese el medio de transporte para la ida (bus/avion): ");
            transporteIda = scanner.nextLine().toLowerCase();
        }

        System.out.print("Ingrese el medio de transporte para la vuelta (bus/avion): ");
        String transporteVuelta = scanner.nextLine().toLowerCase();
        while (!transporteVuelta.equals("bus") && !transporteVuelta.equals("avion")) {
            System.out.println("Opción no válida. Por favor, ingrese 'bus' o 'avion'.");
            System.out.print("Ingrese el medio de transporte para la vuelta (bus/avion): ");
            transporteVuelta = scanner.nextLine().toLowerCase();
        }

        // Calcular costos
        double costoHospedaje = calcularCostoHospedaje(noches);
        double costoTransporte = calcularCostoTransporte(transporteIda, transporteVuelta);
        double costoTotal = calcularCostoTotal(costoHospedaje, costoTransporte);

        // Formatear los números con separadores de miles
        String costoHospedajeFormateado = formatearNumero(costoHospedaje);
        String costoTransporteFormateado = formatearNumero(costoTransporte);
        String costoTotalFormateado = formatearNumero(costoTotal);

        // Mostrar factura
        System.out.println("\n--- Factura ATLAS ---");
        System.out.println("Noches de hospedaje: " + noches + " - Costo: $" + costoHospedajeFormateado);
        System.out.println("Transporte ida: " + transporteIda + " - Transporte vuelta: " + transporteVuelta + " - Costo: $" + costoTransporteFormateado);
        System.out.println("Costo total del paquete (incluye 20% de servicio): $" + costoTotalFormateado);
        System.out.println("Gracias por elegir ATLAS para su viaje al concierto!");

        scanner.close(); // Cerrar el scanner
    }
}